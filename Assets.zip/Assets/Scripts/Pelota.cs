using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pelota : MonoBehaviour
{
    public float velocidadMov;
    public float velocidadExtra;
    public float velocidadMaxima;

    int ContadorGolpes = 0;
    void Start()
    {
        StartCoroutine(IniciarPelota());
    }
    public IEnumerator IniciarPelota(bool ComienzaJugador1 = true)
    {
        PosicionarPelota(ComienzaJugador1);
        ContadorGolpes = 0;
        yield return new WaitForSeconds(2);

        if(ComienzaJugador1)
        {
            MovimientoBola(new Vector2(-1, 0f));
        }
        else
        {
            MovimientoBola(new Vector2(1, 0f));
        }
    }
    void PosicionarPelota(bool ComienzaJugador1)
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);

        if(ComienzaJugador1)
        {
            gameObject.transform.localPosition = new Vector3(-100, 0, 1);
        }
        else
        {
            gameObject.transform.localPosition = new Vector3(100, 0, 1);
        }

    }
    public void MovimientoBola(Vector2 dir)
    {
        dir = dir.normalized;
        float velocidad = velocidadMov + ContadorGolpes * velocidadExtra;
        Rigidbody2D cuepoRigido2D = gameObject.GetComponent<Rigidbody2D>();

        cuepoRigido2D.velocity = dir * velocidad;
    }
    public void AumentarContadorGolpes()
    {
        if(ContadorGolpes*velocidadExtra <= velocidadMaxima)
        {
            ContadorGolpes++;
        }
            
   
    }
}
