using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlDireccion : MonoBehaviour
{
    public Pelota muevePelota;
    public ControlPuntos puntaje;
    void ReboteConRaqueta(Collision2D c)
    {
        Vector3 posicionpelota = this.transform.position;
        Vector3 posicionraqueta = c.gameObject.transform.position;
        float alturaRaqueta = c.collider.bounds.size.y;

        float x;
        if (c.gameObject.name == "RaquetaIzquierda")
        {
            x = 1;
        }
        else
        {
            x = -1;
        }
        float y = (posicionpelota.y - posicionraqueta.y) / alturaRaqueta;

        muevePelota.AumentarContadorGolpes();
        muevePelota.MovimientoBola(new Vector2(x,y));
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name == "RaquetaIzquierda" || collision.gameObject.name == "RaquetaDerecha")
        {
            ReboteConRaqueta(collision);
        }
        else if(collision.gameObject.name == "ParedIzquierda")
        {
            puntaje.PuntajeSumar2();
            StartCoroutine(muevePelota.IniciarPelota(true));
        }
        else if (collision.gameObject.name == "ParedDerecha")
        {
            puntaje.PuntajeSumar1();
            StartCoroutine(muevePelota.IniciarPelota(false));
        }
    }
}
