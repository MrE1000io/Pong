using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Raqueta2 : MonoBehaviour

{
    public float velocidadMov;
    void FixedUpdate()
    {
        float vertical = Input.GetAxisRaw("Vertical2");
        GetComponent<Rigidbody2D>().velocity = new Vector2(0f, vertical * velocidadMov);
    }
}
