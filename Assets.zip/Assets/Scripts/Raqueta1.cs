using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Raqueta1 : MonoBehaviour
{
    public float velocidadMov;
    void FixedUpdate()
    {
        float vertical = Input.GetAxisRaw("Vertical");
        GetComponent<Rigidbody2D>().velocity = new Vector2(0f, vertical * velocidadMov);
    }
}
