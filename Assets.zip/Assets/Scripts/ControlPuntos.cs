using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ControlPuntos : MonoBehaviour
{
    private int puntajeJugador1 = 0;
    private int puntajeJugador2 = 0;

    public GameObject textoPuntaje1;
    public GameObject textoPuntaje2;

    public int metaParaGanar;

    void Update()
    {
        if(puntajeJugador1 >= metaParaGanar || puntajeJugador2 >= metaParaGanar)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
    private void FixedUpdate()
    {
        Text EtiquetaPuntaje1 = textoPuntaje1.GetComponent<Text>();
        Text EtiquetaPuntaje2 = textoPuntaje2.GetComponent<Text>();

        EtiquetaPuntaje1.text = puntajeJugador1.ToString();
        EtiquetaPuntaje2.text = puntajeJugador2.ToString();
    }
    public void PuntajeSumar1()
    {
        puntajeJugador1++;
    }
    public void PuntajeSumar2()
    {
        puntajeJugador2++;
    }

}
