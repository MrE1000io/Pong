using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlSonido : MonoBehaviour
{
    public AudioSource sonidoRaqueta;
    public AudioSource sonidoPared;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name == "RaquetaIzquierda" || collision.gameObject.name == "RaquetaDerecha")
        {
            sonidoRaqueta.Play();
        }
        else
        {
            sonidoPared.Play();
        }
    }
}
